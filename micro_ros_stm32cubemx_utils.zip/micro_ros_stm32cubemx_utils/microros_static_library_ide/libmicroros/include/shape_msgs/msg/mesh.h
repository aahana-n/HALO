// generated from rosidl_generator_c/resource/idl.h.em
// with input from shape_msgs:msg/Mesh.idl
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__MESH_H_
#define SHAPE_MSGS__MSG__MESH_H_

#include "shape_msgs/msg/detail/mesh__struct.h"
#include "shape_msgs/msg/detail/mesh__functions.h"
#include "shape_msgs/msg/detail/mesh__type_support.h"

#endif  // SHAPE_MSGS__MSG__MESH_H_
