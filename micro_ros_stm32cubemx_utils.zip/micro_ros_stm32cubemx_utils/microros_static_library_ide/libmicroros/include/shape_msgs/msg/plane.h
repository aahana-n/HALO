// generated from rosidl_generator_c/resource/idl.h.em
// with input from shape_msgs:msg/Plane.idl
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__PLANE_H_
#define SHAPE_MSGS__MSG__PLANE_H_

#include "shape_msgs/msg/detail/plane__struct.h"
#include "shape_msgs/msg/detail/plane__functions.h"
#include "shape_msgs/msg/detail/plane__type_support.h"

#endif  // SHAPE_MSGS__MSG__PLANE_H_
