// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:srv/SetCameraInfo.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__SRV__SET_CAMERA_INFO_H_
#define SENSOR_MSGS__SRV__SET_CAMERA_INFO_H_

#include "sensor_msgs/srv/detail/set_camera_info__struct.h"
#include "sensor_msgs/srv/detail/set_camera_info__functions.h"
#include "sensor_msgs/srv/detail/set_camera_info__type_support.h"

#endif  // SENSOR_MSGS__SRV__SET_CAMERA_INFO_H_
