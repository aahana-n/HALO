// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/Joy.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__JOY_H_
#define SENSOR_MSGS__MSG__JOY_H_

#include "sensor_msgs/msg/detail/joy__struct.h"
#include "sensor_msgs/msg/detail/joy__functions.h"
#include "sensor_msgs/msg/detail/joy__type_support.h"

#endif  // SENSOR_MSGS__MSG__JOY_H_
