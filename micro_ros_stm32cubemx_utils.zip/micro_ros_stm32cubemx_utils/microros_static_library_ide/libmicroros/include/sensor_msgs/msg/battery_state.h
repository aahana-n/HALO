// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/BatteryState.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__BATTERY_STATE_H_
#define SENSOR_MSGS__MSG__BATTERY_STATE_H_

#include "sensor_msgs/msg/detail/battery_state__struct.h"
#include "sensor_msgs/msg/detail/battery_state__functions.h"
#include "sensor_msgs/msg/detail/battery_state__type_support.h"

#endif  // SENSOR_MSGS__MSG__BATTERY_STATE_H_
