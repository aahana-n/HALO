// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/RegionOfInterest.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__REGION_OF_INTEREST_H_
#define SENSOR_MSGS__MSG__REGION_OF_INTEREST_H_

#include "sensor_msgs/msg/detail/region_of_interest__struct.h"
#include "sensor_msgs/msg/detail/region_of_interest__functions.h"
#include "sensor_msgs/msg/detail/region_of_interest__type_support.h"

#endif  // SENSOR_MSGS__MSG__REGION_OF_INTEREST_H_
