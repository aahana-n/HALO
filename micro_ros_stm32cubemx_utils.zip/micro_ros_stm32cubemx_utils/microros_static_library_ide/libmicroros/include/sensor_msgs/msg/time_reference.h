// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/TimeReference.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__TIME_REFERENCE_H_
#define SENSOR_MSGS__MSG__TIME_REFERENCE_H_

#include "sensor_msgs/msg/detail/time_reference__struct.h"
#include "sensor_msgs/msg/detail/time_reference__functions.h"
#include "sensor_msgs/msg/detail/time_reference__type_support.h"

#endif  // SENSOR_MSGS__MSG__TIME_REFERENCE_H_
