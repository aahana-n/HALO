// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/NavSatFix.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__NAV_SAT_FIX_H_
#define SENSOR_MSGS__MSG__NAV_SAT_FIX_H_

#include "sensor_msgs/msg/detail/nav_sat_fix__struct.h"
#include "sensor_msgs/msg/detail/nav_sat_fix__functions.h"
#include "sensor_msgs/msg/detail/nav_sat_fix__type_support.h"

#endif  // SENSOR_MSGS__MSG__NAV_SAT_FIX_H_
