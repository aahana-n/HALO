// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/JointState.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__JOINT_STATE_H_
#define SENSOR_MSGS__MSG__JOINT_STATE_H_

#include "sensor_msgs/msg/detail/joint_state__struct.h"
#include "sensor_msgs/msg/detail/joint_state__functions.h"
#include "sensor_msgs/msg/detail/joint_state__type_support.h"

#endif  // SENSOR_MSGS__MSG__JOINT_STATE_H_
