// generated from rosidl_generator_c/resource/idl.h.em
// with input from tf2_msgs:msg/TF2Error.idl
// generated code does not contain a copyright notice

#ifndef TF2_MSGS__MSG__TF2_ERROR_H_
#define TF2_MSGS__MSG__TF2_ERROR_H_

#include "tf2_msgs/msg/detail/tf2_error__struct.h"
#include "tf2_msgs/msg/detail/tf2_error__functions.h"
#include "tf2_msgs/msg/detail/tf2_error__type_support.h"

#endif  // TF2_MSGS__MSG__TF2_ERROR_H_
