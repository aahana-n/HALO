// generated from rosidl_generator_c/resource/idl.h.em
// with input from visualization_msgs:msg/InteractiveMarkerUpdate.idl
// generated code does not contain a copyright notice

#ifndef VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_UPDATE_H_
#define VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_UPDATE_H_

#include "visualization_msgs/msg/detail/interactive_marker_update__struct.h"
#include "visualization_msgs/msg/detail/interactive_marker_update__functions.h"
#include "visualization_msgs/msg/detail/interactive_marker_update__type_support.h"

#endif  // VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_UPDATE_H_
