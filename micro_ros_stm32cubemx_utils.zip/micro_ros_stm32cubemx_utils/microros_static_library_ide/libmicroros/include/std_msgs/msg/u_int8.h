// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/UInt8.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__U_INT8_H_
#define STD_MSGS__MSG__U_INT8_H_

#include "std_msgs/msg/detail/u_int8__struct.h"
#include "std_msgs/msg/detail/u_int8__functions.h"
#include "std_msgs/msg/detail/u_int8__type_support.h"

#endif  // STD_MSGS__MSG__U_INT8_H_
