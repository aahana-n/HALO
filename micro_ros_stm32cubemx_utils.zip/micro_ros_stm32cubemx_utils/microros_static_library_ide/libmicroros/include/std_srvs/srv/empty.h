// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_srvs:srv/Empty.idl
// generated code does not contain a copyright notice

#ifndef STD_SRVS__SRV__EMPTY_H_
#define STD_SRVS__SRV__EMPTY_H_

#include "std_srvs/srv/detail/empty__struct.h"
#include "std_srvs/srv/detail/empty__functions.h"
#include "std_srvs/srv/detail/empty__type_support.h"

#endif  // STD_SRVS__SRV__EMPTY_H_
